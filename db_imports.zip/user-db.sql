-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Hôte : user-db:3306
-- Généré le : jeu. 27 mars 2025 à 19:54
-- Version du serveur : 8.0.41
-- Version de PHP : 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `user_db`
--
CREATE DATABASE IF NOT EXISTS `user_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `user_db`;

-- --------------------------------------------------------

--
-- Structure de la table `addresses`
--

CREATE TABLE `addresses` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `userId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `type` enum('billing','shipping','both') DEFAULT 'both',
  `street` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `isDefault` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `addresses`
--

INSERT INTO `addresses` (`id`, `userId`, `type`, `street`, `city`, `state`, `postalCode`, `country`, `isDefault`, `createdAt`, `updatedAt`) VALUES
('07378971-080c-11f0-bc61-0242ac150004', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'both', '123 Rue de l\'Administration', 'Paris', 'ÃŽle-de-France', '75001', 'France', 1, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('0737ced0-080c-11f0-bc61-0242ac150004', 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'both', '456 Avenue des Organisateurs', 'Lyon', 'Auvergne-RhÃ´ne-Alpes', '69001', 'France', 1, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('0737d333-080c-11f0-bc61-0242ac150004', 'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'both', '789 Boulevard des Ã‰vÃ©nements', 'Marseille', 'Provence-Alpes-CÃ´te d\'Azur', '13001', 'France', 1, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('0737d4d5-080c-11f0-bc61-0242ac150004', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'billing', '101 Rue des Utilisateurs', 'Bordeaux', 'Nouvelle-Aquitaine', '33000', 'France', 1, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('0737d5e0-080c-11f0-bc61-0242ac150004', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'shipping', '102 Rue des Livraisons', 'Bordeaux', 'Nouvelle-Aquitaine', '33000', 'France', 0, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('0737d6d0-080c-11f0-bc61-0242ac150004', 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'both', '202 Avenue des Clients', 'Lille', 'Hauts-de-France', '59000', 'France', 1, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('0737d7b5-080c-11f0-bc61-0242ac150004', 'f0eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 'both', '303 Boulevard des Acheteurs', 'Toulouse', 'Occitanie', '31000', 'France', 1, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('0737d8a4-080c-11f0-bc61-0242ac150004', 'g0eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 'both', '404 Rue des Participants', 'Nantes', 'Pays de la Loire', '44000', 'France', 1, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('0737d99a-080c-11f0-bc61-0242ac150004', 'h0eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 'both', '505 Avenue des Spectateurs', 'Strasbourg', 'Grand Est', '67000', 'France', 1, '2025-03-23 17:27:00', '2025-03-23 17:27:00');

-- --------------------------------------------------------

--
-- Structure de la table `userProfiles`
--

CREATE TABLE `userProfiles` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `userId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(255) DEFAULT NULL,
  `birthDate` date DEFAULT NULL,
  `profilePicture` varchar(255) DEFAULT NULL,
  `preferences` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `userProfiles`
--

INSERT INTO `userProfiles` (`id`, `userId`, `username`, `email`, `firstName`, `lastName`, `phoneNumber`, `birthDate`, `profilePicture`, `preferences`, `createdAt`, `updatedAt`) VALUES
('4004f0ae-9eb8-424f-b499-2f1a9e3a1ebf', 'ce3a7002-f963-4e15-b81c-b1811c5474d5', 'newuser', 'newuser@example.com', NULL, NULL, NULL, NULL, NULL, '{}', '2025-03-24 10:25:55', '2025-03-24 10:25:55'),
('972ac16e-fc10-4a43-aa06-d15d62eac7f2', '063ee2ac-b381-4f59-b9e3-5845ede3febc', 'admintest', 'admintest@tonticket.com', NULL, NULL, NULL, NULL, NULL, '{}', '2025-03-24 13:17:22', '2025-03-24 13:17:22'),
('a1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'admin', 'admin@tonticket.fr', 'Admin', 'User', '+33123456789', NULL, 'https://randomuser.me/api/portraits/men/1.jpg', '{\"description\": \"Administrateur de la plateforme Ton Ticket\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'organizer1', 'organizer1@tonticket.fr', 'Jean', 'Dupont', '+33123456790', NULL, 'https://randomuser.me/api/portraits/men/2.jpg', '{\"description\": \"Organisateur d\'Ã©vÃ©nements musicaux\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('c1eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'organizer2', 'organizer2@tonticket.fr', 'Marie', 'Martin', '+33123456791', NULL, 'https://randomuser.me/api/portraits/women/1.jpg', '{\"description\": \"Organisatrice d\'Ã©vÃ©nements sportifs\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('d1eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'user1', 'user1@example.com', 'Pierre', 'Durand', '+33123456792', NULL, 'https://randomuser.me/api/portraits/men/3.jpg', '{\"description\": \"Amateur de concerts et festivals\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('d44d672e-1365-4c05-8bdc-3965349d59ae', 'a55c60f1-54bc-409f-bcb5-bc12f52bd8c0', 'testuser', 'testuser@example.com', NULL, NULL, NULL, NULL, NULL, '{}', '2025-03-24 09:49:01', '2025-03-24 09:49:01'),
('e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'user2', 'user2@example.com', 'Sophie', 'Leroy', '+33123456793', NULL, 'https://randomuser.me/api/portraits/women/2.jpg', '{\"description\": \"PassionnÃ©e de thÃ©Ã¢tre\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('f1eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 'f0eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 'user3', 'user3@example.com', 'Thomas', 'Moreau', '+33123456794', NULL, 'https://randomuser.me/api/portraits/men/4.jpg', '{\"description\": \"Fan de sports et compÃ©titions\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('g1eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 'g0eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 'user4', 'user4@example.com', 'Julie', 'Petit', '+33123456795', NULL, 'https://randomuser.me/api/portraits/women/3.jpg', '{\"description\": \"Amatrice d\'art et expositions\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('h1eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 'h0eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 'user5', 'user5@example.com', 'Lucas', 'Roux', '+33123456796', NULL, 'https://randomuser.me/api/portraits/men/5.jpg', '{\"description\": \"PassionnÃ© de confÃ©rences tech\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Index pour la table `userProfiles`
--
ALTER TABLE `userProfiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userId` (`userId`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `userProfiles` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
