-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Hôte : event-db:3306
-- Généré le : jeu. 27 mars 2025 à 19:55
-- Version du serveur : 8.0.41
-- Version de PHP : 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `event_db`
--
CREATE DATABASE IF NOT EXISTS `event_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `event_db`;

-- --------------------------------------------------------

--
-- Structure de la table `eventCategories`
--

CREATE TABLE `eventCategories` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `eventCategories`
--

INSERT INTO `eventCategories` (`id`, `name`, `description`, `icon`, `color`, `createdAt`, `updatedAt`) VALUES
('13cf30a2-080b-11f0-bd99-0242ac150002', 'Concert', 'Evenements musicaux, concerts et festivals', 'music_note', '#1E88E5', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13cf4804-080b-11f0-bd99-0242ac150002', 'Théâtre', 'Pièce de théâtre et spectacles', 'theater_comedy', '#43A047', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13cf4b2b-080b-11f0-bd99-0242ac150002', 'Sport', 'Evenements sportifs et compétitions', 'sports_soccer', '#E53935', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13cf4c13-080b-11f0-bd99-0242ac150002', 'Conférence', 'Conférences, séminaires et ateliers', 'event_note', '#FB8C00', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13cf4ca2-080b-11f0-bd99-0242ac150002', 'Exposition', 'Expositions artistiques et culturelles', 'palette', '#8E24AA', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13cf4d2d-080b-11f0-bd99-0242ac150002', 'Festival', 'Festivals culturels et artistiques', 'festival', '#F4511E', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13cf4d9a-080b-11f0-bd99-0242ac150002', 'Cinéma', 'Projections de films et avant-premières', 'movie', '#6D4C41', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13cf4e0b-080b-11f0-bd99-0242ac150002', 'Gastronomie', 'Evenements culinaires et dégustations', 'restaurant', '#00ACC1', '2025-03-23 17:20:11', '2025-03-23 17:20:11');

-- --------------------------------------------------------

--
-- Structure de la table `eventImages`
--

CREATE TABLE `eventImages` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `eventId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `imageUrl` varchar(255) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `sortOrder` int DEFAULT '0',
  `isActive` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `events`
--

CREATE TABLE `events` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL,
  `organizerId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `venueId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `categoryId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `status` enum('draft','published','cancelled') DEFAULT 'draft',
  `featuredImage` varchar(255) DEFAULT NULL,
  `capacity` int NOT NULL,
  `ticketsAvailable` int NOT NULL,
  `ticketPrice` decimal(10,2) NOT NULL,
  `currency` varchar(255) DEFAULT 'EUR',
  `isPublic` tinyint(1) DEFAULT '1',
  `tags` json DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `startDate`, `endDate`, `organizerId`, `venueId`, `categoryId`, `status`, `featuredImage`, `capacity`, `ticketsAvailable`, `ticketPrice`, `currency`, `isPublic`, `tags`, `metadata`, `createdAt`, `updatedAt`) VALUES
('3f7b10a2-df09-4186-8105-cde827856554', 'Evenement de Test Admin', 'event', '2025-04-15 19:00:00', '2025-04-15 22:00:00', '063ee2ac-b381-4f59-b9e3-5845ede3febc', 'v2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', '13cf4d9a-080b-11f0-bd99-0242ac150002', 'draft', NULL, 100, 100, 25.00, 'EUR', 1, '[]', '{}', '2025-03-24 15:25:00', '2025-03-24 15:25:00'),
('e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 'Concert - Rock Legends', 'Les plus grandes légendes du rock réunies pour un concert exceptionnel.', '2025-10-15 19:30:00', '2025-10-15 23:30:00', 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'v2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', '13cf30a2-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a', 20000, 0, 95.00, 'EUR', 1, NULL, '{\"featured\": true}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Festival de Musique électronique', 'Le plus grand festival de musique électronique de l\'année avec les meilleurs DJs internationaux.', '2025-06-15 18:00:00', '2025-06-16 02:00:00', 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'v1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', '13cf30a2-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3', 6000, 101, 75.00, 'EUR', 1, NULL, '{\"featured\": true}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'Concert Symphonique - Beethoven', 'Une soirée exceptionnelle dédiée aux oeuvres de Beethoven interprétés par l\'Orchestre Philharmonique.', '2025-04-10 20:00:00', '2025-04-10 22:30:00', 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'v2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', '13cf30a2-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1507676184212-d03ab07a01bf', 15000, 0, 60.00, 'EUR', 1, NULL, '{\"featured\": false}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'Finale Coupe de France', 'Match final de la Coupe de France de football.', '2025-04-25 21:00:00', '2025-04-25 23:00:00', 'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'v4eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', '13cf4b2b-080b-11f0-bd99-0242ac150002', 'published', 'https://www.lequipe.fr/_medias/img-photo-jpg/warren-zaire-emery-est-de-retour-dans-le-groupe-du-psg-apres-sa-blessure-face-a-stuttgart-le-29-janv/1500000002153280/0:0,2000:1333-828-552-75/8a717.jpg', 80000, 0, 120.00, 'EUR', 1, NULL, '{\"featured\": true}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e4eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'Conférence sur l\'Intelligence Artificielle', 'Les experts mondiaux se réunissent pour discuter des dernières avancées en IA.', '2025-05-15 09:00:00', '2025-05-17 18:00:00', 'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'v5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', '13cf4c13-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678', 3000, 0, 250.00, 'EUR', 1, NULL, '{\"featured\": false}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'Exposition d\'Art Contemporain', 'Découvrez les oeuvres des artistes contemporains les plus innovants.', '2025-08-01 10:00:00', '2025-08-20 19:00:00', 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'v6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', '13cf4ca2-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1531058020387-3be344556be6', 5000, 0, 15.00, 'EUR', 1, NULL, '{\"featured\": true}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 'Festival de Jazz', 'Trois jours de jazz avec les meilleurs musiciens internationaux.', '2025-07-20 17:00:00', '2025-07-22 23:00:00', 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'v7eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', '13cf4d2d-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1511192336575-5a79af67a629', 1300, 0, 85.00, 'EUR', 1, NULL, '{\"featured\": true}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e7eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 'Avant-première - Nouveau Blockbuster', 'Soyez les premiers à découvrir le film événement de l\'année en présence de l\'équipe du film.', '2025-05-30 20:30:00', '2025-05-30 23:00:00', 'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'v8eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', '13cf4d9a-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba', 1900, 0, 25.00, 'EUR', 1, NULL, '{\"featured\": false}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e8eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 'Festival Gastronomique', 'Découvrez les spécialités culinaires de grands chefs lors de ce festival gastronomique.', '2025-09-10 11:00:00', '2025-09-12 22:00:00', 'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'v5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', '13cf4e0b-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0', 2500, 0, 45.00, 'EUR', 1, NULL, '{\"featured\": true}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('e9eebc99-9c0b-4ef8-bb6d-6bb9bd380a19', 'Pièce de Théâtre - Les Misérables', 'Une adaptation moderne du chef-d\'oeuvre de Victor Hugo.', '2025-06-05 20:00:00', '2025-06-05 23:00:00', 'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'v3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', '13cf4804-080b-11f0-bd99-0242ac150002', 'published', 'https://images.unsplash.com/photo-1503095396549-807759245b35', 2000, 0, 55.00, 'EUR', 1, NULL, '{\"featured\": false}', '2025-03-23 17:37:10', '2025-03-23 17:37:10');

-- --------------------------------------------------------

--
-- Structure de la table `venues`
--

CREATE TABLE `venues` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `capacity` int NOT NULL,
  `description` text,
  `contactEmail` varchar(255) DEFAULT NULL,
  `contactPhone` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `amenities` json DEFAULT NULL,
  `images` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `venues`
--

INSERT INTO `venues` (`id`, `name`, `address`, `city`, `state`, `postalCode`, `country`, `capacity`, `description`, `contactEmail`, `contactPhone`, `website`, `latitude`, `longitude`, `amenities`, `images`, `createdAt`, `updatedAt`) VALUES
('66094538-dc16-4eff-8399-ca7f8ddea157', 'Salle de Test Admin', '123 Rue de Test', 'Paris', NULL, '75001', 'France', 500, 'Salle de test cr��e par un administrateur', NULL, NULL, NULL, NULL, NULL, '[]', '[]', '2025-03-24 15:24:22', '2025-03-24 15:24:22'),
('v1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Zénith de Paris', '211 Avenue Jean Jaurès', 'Paris', 'Ile-de-France', '75019', 'France', 6300, 'Grande salle de concert parisienne', NULL, NULL, NULL, NULL, NULL, '{\"bar\": true, \"parking\": true, \"foodServices\": true, \"handicapAccess\": true}', NULL, '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('v2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'AccorHotels Arena', '8 Boulevard de Bercy', 'Paris', 'Ile-de-France', '75012', 'France', 20300, 'Plus grande salle de spectacle couverte de France', NULL, NULL, NULL, NULL, NULL, '{\"bar\": true, \"vip\": true, \"parking\": true, \"foodServices\": true, \"handicapAccess\": true}', NULL, '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('v3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'Théâtre du Châtelet', '2 Rue Edouard Colonne', 'Paris', 'Ile-de-France', '75001', 'France', 2010, 'ThÃ©Ã¢tre municipal parisien', NULL, NULL, NULL, NULL, NULL, '{\"bar\": true, \"handicapAccess\": true}', NULL, '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('v4eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'Stade de France', '93200 Saint-Denis', 'Saint-Denis', 'Ile-de-France', '93200', 'France', 80000, 'Plus grand stade de France', NULL, NULL, NULL, NULL, NULL, '{\"bar\": true, \"vip\": true, \"parking\": true, \"foodServices\": true, \"handicapAccess\": true}', NULL, '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('v5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'Palais des Congrès', '2 Place de la Porte Maillot', 'Paris', 'Ile-de-France', '75017', 'France', 3723, 'Centre de congrès et salle de spectacle', NULL, NULL, NULL, NULL, NULL, '{\"wifi\": true, \"parking\": true, \"foodServices\": true, \"handicapAccess\": true}', NULL, '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('v6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 'Grand Palais', '3 Avenue du GÃ©nÃ©ral Eisenhower', 'Paris', 'Ile-de-France', '75008', 'France', 5000, 'Monument historique et lieu d\'exposition', NULL, NULL, NULL, NULL, NULL, '{\"foodServices\": true, \"handicapAccess\": true}', NULL, '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('v7eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 'La Cigale', '120 Boulevard de Rochechouart', 'Paris', 'Ile-de-France', '75018', 'France', 1389, 'Salle de concert mythique', NULL, NULL, NULL, NULL, NULL, '{\"bar\": true}', NULL, '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('v8eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 'Olympia', '28 Boulevard des Capucines', 'Paris', 'Ile-de-France', '75009', 'France', 1996, 'Salle de spectacle emblématique', NULL, NULL, NULL, NULL, NULL, '{\"bar\": true, \"handicapAccess\": true}', NULL, '2025-03-23 17:20:11', '2025-03-23 17:20:11');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `eventCategories`
--
ALTER TABLE `eventCategories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Index pour la table `eventImages`
--
ALTER TABLE `eventImages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eventId` (`eventId`);

--
-- Index pour la table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `venueId` (`venueId`),
  ADD KEY `categoryId` (`categoryId`);

--
-- Index pour la table `venues`
--
ALTER TABLE `venues`
  ADD PRIMARY KEY (`id`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `eventImages`
--
ALTER TABLE `eventImages`
  ADD CONSTRAINT `eventImages_ibfk_1` FOREIGN KEY (`eventId`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`venueId`) REFERENCES `venues` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `events_ibfk_2` FOREIGN KEY (`categoryId`) REFERENCES `eventCategories` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
