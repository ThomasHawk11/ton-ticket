-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Hôte : ticket-db:3306
-- Généré le : jeu. 27 mars 2025 à 19:56
-- Version du serveur : 8.0.41
-- Version de PHP : 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ticket_db`
--
CREATE DATABASE IF NOT EXISTS `ticket_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `ticket_db`;

-- --------------------------------------------------------

--
-- Structure de la table `ticketInventories`
--

CREATE TABLE `ticketInventories` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `eventId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `totalTickets` int NOT NULL,
  `availableTickets` int NOT NULL,
  `reservedTickets` int DEFAULT '0',
  `soldTickets` int DEFAULT '0',
  `cancelledTickets` int DEFAULT '0',
  `basePrice` decimal(10,2) NOT NULL,
  `currency` varchar(255) DEFAULT 'EUR',
  `saleStartDate` datetime NOT NULL,
  `saleEndDate` datetime NOT NULL,
  `status` enum('draft','active','paused','sold_out','closed') DEFAULT 'draft',
  `metadata` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `ticketInventories`
--

INSERT INTO `ticketInventories` (`id`, `eventId`, `totalTickets`, `availableTickets`, `reservedTickets`, `soldTickets`, `cancelledTickets`, `basePrice`, `currency`, `saleStartDate`, `saleEndDate`, `status`, `metadata`, `createdAt`, `updatedAt`) VALUES
('074adda6-080c-11f0-aff0-0242ac150003', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 5000, 4798, 2, 200, 0, 75.00, 'EUR', '2025-02-21 17:27:00', '2025-05-22 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-27 12:13:06'),
('074ae82b-080c-11f0-aff0-0242ac150003', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 1000, 950, 0, 50, 0, 150.00, 'EUR', '2025-02-21 17:27:00', '2025-05-22 17:27:00', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074ae93d-080c-11f0-aff0-0242ac150003', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 1800, 1750, 0, 50, 0, 60.00, 'EUR', '2025-02-21 17:27:00', '2025-04-22 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074aec67-080c-11f0-aff0-0242ac150003', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 200, 180, 0, 20, 0, 90.00, 'EUR', '2025-02-21 17:27:00', '2025-04-22 17:27:00', 'active', '{\"ticketType\": \"premium\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074aedd5-080c-11f0-aff0-0242ac150003', 'e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 70000, 69500, 0, 500, 0, 120.00, 'EUR', '2025-03-08 17:27:00', '2025-04-07 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074aeeb2-080c-11f0-aff0-0242ac150003', 'e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 10000, 9900, 0, 100, 0, 250.00, 'EUR', '2025-03-08 17:27:00', '2025-04-07 17:27:00', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074aefd9-080c-11f0-aff0-0242ac150003', 'e4eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 3000, 2950, 0, 50, 0, 150.00, 'EUR', '2025-01-22 17:27:00', '2025-06-21 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074af0a1-080c-11f0-aff0-0242ac150003', 'e5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 5000, 4900, 0, 100, 0, 15.00, 'EUR', '2025-02-21 17:27:00', '2025-07-21 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074af16c-080c-11f0-aff0-0242ac150003', 'e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 1200, 1150, 0, 50, 0, 85.00, 'EUR', '2025-02-06 17:27:00', '2025-05-07 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074af225-080c-11f0-aff0-0242ac150003', 'e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 100, 80, 0, 20, 0, 150.00, 'EUR', '2025-02-06 17:27:00', '2025-05-07 17:27:00', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074af2d6-080c-11f0-aff0-0242ac150003', 'e7eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 1900, 1850, 0, 50, 0, 25.00, 'EUR', '2025-02-21 17:27:00', '2025-04-07 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074af37c-080c-11f0-aff0-0242ac150003', 'e8eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 2500, 2450, 0, 50, 0, 45.00, 'EUR', '2025-01-22 17:27:00', '2025-05-22 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074af43e-080c-11f0-aff0-0242ac150003', 'e9eebc99-9c0b-4ef8-bb6d-6bb9bd380a19', 2000, 1950, 0, 50, 0, 55.00, 'EUR', '2025-02-06 17:27:00', '2025-04-22 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074af696-080c-11f0-aff0-0242ac150003', 'e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 18000, 17800, 0, 200, 0, 95.00, 'EUR', '2024-12-23 17:27:00', '2025-07-21 17:27:00', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074af7d7-080c-11f0-aff0-0242ac150003', 'e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 2000, 1950, 0, 50, 0, 195.00, 'EUR', '2024-12-23 17:27:00', '2025-07-21 17:27:00', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('13e300c0-080b-11f0-aff0-0242ac150003', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 5000, 4800, 0, 200, 0, 75.00, 'EUR', '2025-02-21 17:20:11', '2025-05-22 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e3162f-080b-11f0-aff0-0242ac150003', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 1000, 950, 0, 50, 0, 150.00, 'EUR', '2025-02-21 17:20:11', '2025-05-22 17:20:11', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31970-080b-11f0-aff0-0242ac150003', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 1800, 1750, 0, 50, 0, 60.00, 'EUR', '2025-02-21 17:20:11', '2025-04-22 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31a7c-080b-11f0-aff0-0242ac150003', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 200, 180, 0, 20, 0, 90.00, 'EUR', '2025-02-21 17:20:11', '2025-04-22 17:20:11', 'active', '{\"ticketType\": \"premium\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31b0d-080b-11f0-aff0-0242ac150003', 'e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 70000, 69500, 0, 500, 0, 120.00, 'EUR', '2025-03-08 17:20:11', '2025-04-07 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31b81-080b-11f0-aff0-0242ac150003', 'e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 10000, 9900, 0, 100, 0, 250.00, 'EUR', '2025-03-08 17:20:11', '2025-04-07 17:20:11', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31bf0-080b-11f0-aff0-0242ac150003', 'e4eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 3000, 2950, 0, 50, 0, 150.00, 'EUR', '2025-01-22 17:20:11', '2025-06-21 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31c5c-080b-11f0-aff0-0242ac150003', 'e5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 5000, 4900, 0, 100, 0, 15.00, 'EUR', '2025-02-21 17:20:11', '2025-07-21 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31cd2-080b-11f0-aff0-0242ac150003', 'e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 1200, 1150, 0, 50, 0, 85.00, 'EUR', '2025-02-06 17:20:11', '2025-05-07 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31d3f-080b-11f0-aff0-0242ac150003', 'e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 100, 80, 0, 20, 0, 150.00, 'EUR', '2025-02-06 17:20:11', '2025-05-07 17:20:11', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31da7-080b-11f0-aff0-0242ac150003', 'e7eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 1900, 1850, 0, 50, 0, 25.00, 'EUR', '2025-02-21 17:20:11', '2025-04-07 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31e05-080b-11f0-aff0-0242ac150003', 'e8eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 2500, 2450, 0, 50, 0, 45.00, 'EUR', '2025-01-22 17:20:11', '2025-06-21 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31e6b-080b-11f0-aff0-0242ac150003', 'e9eebc99-9c0b-4ef8-bb6d-6bb9bd380a19', 1800, 1750, 0, 50, 0, 55.00, 'EUR', '2025-02-21 17:20:11', '2025-04-22 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e31ef1-080b-11f0-aff0-0242ac150003', 'e9eebc99-9c0b-4ef8-bb6d-6bb9bd380a19', 200, 180, 0, 20, 0, 85.00, 'EUR', '2025-02-21 17:20:11', '2025-04-22 17:20:11', 'active', '{\"ticketType\": \"premium\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e3215a-080b-11f0-aff0-0242ac150003', 'e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 18000, 17800, 0, 200, 0, 95.00, 'EUR', '2024-12-23 17:20:11', '2025-07-21 17:20:11', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('13e321ca-080b-11f0-aff0-0242ac150003', 'e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 2000, 1950, 0, 50, 0, 195.00, 'EUR', '2024-12-23 17:20:11', '2025-07-21 17:20:11', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:20:11', '2025-03-23 17:20:11'),
('72f85e1d-080d-11f0-9d84-0242ac150006', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 5000, 4800, 0, 200, 0, 75.00, 'EUR', '2025-02-21 17:37:10', '2025-05-22 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8aa64-080d-11f0-9d84-0242ac150006', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 1000, 950, 0, 50, 0, 150.00, 'EUR', '2025-02-21 17:37:10', '2025-05-22 17:37:10', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8af19-080d-11f0-9d84-0242ac150006', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 1800, 1750, 0, 50, 0, 60.00, 'EUR', '2025-02-21 17:37:10', '2025-04-22 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b053-080d-11f0-9d84-0242ac150006', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 200, 180, 0, 20, 0, 90.00, 'EUR', '2025-02-21 17:37:10', '2025-04-22 17:37:10', 'active', '{\"ticketType\": \"premium\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b138-080d-11f0-9d84-0242ac150006', 'e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 70000, 69500, 0, 500, 0, 120.00, 'EUR', '2025-03-08 17:37:10', '2025-04-07 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b3cd-080d-11f0-9d84-0242ac150006', 'e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 10000, 9900, 0, 100, 0, 250.00, 'EUR', '2025-03-08 17:37:10', '2025-04-07 17:37:10', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b529-080d-11f0-9d84-0242ac150006', 'e4eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 3000, 2950, 0, 50, 0, 150.00, 'EUR', '2025-01-22 17:37:10', '2025-06-21 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b5cf-080d-11f0-9d84-0242ac150006', 'e5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 5000, 4900, 0, 100, 0, 15.00, 'EUR', '2025-02-21 17:37:10', '2025-07-21 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b665-080d-11f0-9d84-0242ac150006', 'e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 1200, 1150, 0, 50, 0, 85.00, 'EUR', '2025-02-06 17:37:10', '2025-05-07 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b729-080d-11f0-9d84-0242ac150006', 'e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 100, 80, 0, 20, 0, 150.00, 'EUR', '2025-02-06 17:37:10', '2025-05-07 17:37:10', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b7df-080d-11f0-9d84-0242ac150006', 'e7eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 1900, 1850, 0, 50, 0, 25.00, 'EUR', '2025-03-03 17:37:10', '2025-04-02 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b86f-080d-11f0-9d84-0242ac150006', 'e8eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 2500, 2450, 0, 50, 0, 45.00, 'EUR', '2025-01-22 17:37:10', '2025-04-22 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8b920-080d-11f0-9d84-0242ac150006', 'e9eebc99-9c0b-4ef8-bb6d-6bb9bd380a19', 2000, 1950, 0, 50, 0, 55.00, 'EUR', '2025-02-21 17:37:10', '2025-04-07 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8bb31-080d-11f0-9d84-0242ac150006', 'e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 18000, 17900, 0, 100, 0, 95.00, 'EUR', '2024-12-23 17:37:10', '2025-07-21 17:37:10', 'active', '{\"ticketType\": \"standard\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72f8bbde-080d-11f0-9d84-0242ac150006', 'e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 2000, 1950, 0, 50, 0, 195.00, 'EUR', '2024-12-23 17:37:10', '2025-07-21 17:37:10', 'active', '{\"ticketType\": \"vip\"}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', '3f7b10a2-df09-4186-8105-cde827856554', 100, 100, 0, 0, 0, 25.00, 'EUR', '2025-03-24 15:25:00', '2025-04-14 19:00:00', 'active', NULL, '2025-03-24 15:25:00', '2025-03-24 15:25:00');

-- --------------------------------------------------------

--
-- Structure de la table `tickets`
--

CREATE TABLE `tickets` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `eventId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `userId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `inventoryId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `status` enum('available','reserved','purchased','cancelled','used') DEFAULT 'available',
  `price` decimal(10,2) NOT NULL,
  `currency` varchar(255) DEFAULT 'EUR',
  `purchaseDate` datetime DEFAULT NULL,
  `qrCode` varchar(255) DEFAULT NULL,
  `validationCode` varchar(255) DEFAULT NULL,
  `seatInfo` json DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `tickets`
--

INSERT INTO `tickets` (`id`, `eventId`, `userId`, `inventoryId`, `status`, `price`, `currency`, `purchaseDate`, `qrCode`, `validationCode`, `seatInfo`, `metadata`, `createdAt`, `updatedAt`) VALUES
('02419c0d-9e37-44ff-86d8-f157fae498c1', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('03094e58-a7f7-426a-a7ab-442cc6b3aa50', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('0320e524-e035-4d52-aa41-935ddb149c62', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 8, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:47', '2025-03-24 10:40:47'),
('05c84090-696e-47ac-99e8-4504f34e55cf', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('074d8fbe-080c-11f0-aff0-0242ac150003', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', '074adda6-080c-11f0-aff0-0242ac150003', 'purchased', 75.00, 'EUR', '2025-03-23 17:27:00', 'qr_code_data_1', NULL, '{\"row\": \"1\", \"seat\": \"15\", \"section\": \"A\"}', NULL, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074e0f0a-080c-11f0-aff0-0242ac150003', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', '074ae82b-080c-11f0-aff0-0242ac150003', 'purchased', 150.00, 'EUR', '2025-03-23 17:27:00', 'qr_code_data_2', NULL, '{\"row\": \"1\", \"seat\": \"5\", \"section\": \"VIP\"}', NULL, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074e191f-080c-11f0-aff0-0242ac150003', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'f0eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', '074ae93d-080c-11f0-aff0-0242ac150003', 'purchased', 60.00, 'EUR', '2025-03-23 17:27:00', 'qr_code_data_3', NULL, '{\"row\": \"5\", \"seat\": \"10\", \"section\": \"B\"}', NULL, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074e1df8-080c-11f0-aff0-0242ac150003', 'e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', '074aedd5-080c-11f0-aff0-0242ac150003', 'purchased', 120.00, 'EUR', '2025-03-23 17:27:00', 'qr_code_data_4', NULL, '{\"row\": \"20\", \"seat\": \"15\", \"section\": \"C\"}', NULL, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074e2545-080c-11f0-aff0-0242ac150003', 'e5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'g0eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', '074af0a1-080c-11f0-aff0-0242ac150003', 'purchased', 15.00, 'EUR', '2025-03-23 17:27:00', 'qr_code_data_5', NULL, '{\"row\": \"\", \"seat\": \"\", \"section\": \"General\"}', NULL, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074e2a42-080c-11f0-aff0-0242ac150003', 'e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 'h0eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', '074af225-080c-11f0-aff0-0242ac150003', 'purchased', 150.00, 'EUR', '2025-03-23 17:27:00', 'qr_code_data_6', NULL, '{\"row\": \"2\", \"seat\": \"7\", \"section\": \"VIP\"}', NULL, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('074e2da4-080c-11f0-aff0-0242ac150003', 'e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', '074af7d7-080c-11f0-aff0-0242ac150003', 'purchased', 195.00, 'EUR', '2025-03-23 17:27:00', 'qr_code_data_7', NULL, '{\"row\": \"1\", \"seat\": \"10\", \"section\": \"VIP\"}', NULL, '2025-03-23 17:27:00', '2025-03-23 17:27:00'),
('08273ba1-5b42-4deb-bfe3-3a3c3f8617fb', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 5, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:47', '2025-03-24 10:40:47'),
('09874b50-bd5a-41fc-bc89-8df54b006e6d', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('09e1babf-38ff-40df-9033-bcfd3e065e22', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('0aee582e-1512-45d0-a0c6-246edd0f22c9', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('0af307a5-261c-4975-9698-038453df64a1', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 10, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:48', '2025-03-24 10:40:48'),
('10b34059-af60-4f09-8980-780f665a9039', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 4, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:47', '2025-03-24 10:40:47'),
('12877ba1-44f9-496e-bb81-bc077703bf83', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('13ae2c93-aec7-4ca2-82ee-ca544a5ab34f', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('159aae3e-99ee-4071-9b2d-e4b08c139d7f', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 3, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:47', '2025-03-24 10:40:47'),
('1b95e6ff-8d4c-4c22-a5c6-ca2cd89494b5', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('1e506a51-c433-4395-9634-235692ef2c75', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('1ecb83e6-a4ff-4f00-8b53-4c11c89bc5f2', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('1f0f9a7a-ea02-4d21-9a62-9d76bf3787b6', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 9, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:48', '2025-03-24 10:40:48'),
('1f1ed3c0-5bd8-4364-a5eb-b79037891295', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('22bcec1e-b4f6-4a03-9062-a3dc3bd6f4ba', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('2374fa49-600c-41d1-916c-3793369753a8', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('24933cb5-3508-4033-9321-36741fc75468', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('26d273a0-0a9c-471e-8cdc-bf66ce0b777f', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('270a484b-f1e9-4f09-830c-78be2cb48de4', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('2719078c-c271-4a4b-8594-e5ef054146f7', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('294bd0a6-bdf3-48dd-bb56-1630b3cc7898', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('29c6b180-b53a-4625-87c2-e4a3b5862c12', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('2bf8f725-b792-4982-8dea-0f64f9c827c3', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('2db1cda3-046c-4230-9feb-11fa37f30b04', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('2e8fb64b-a097-4e17-8ff0-4b2286fe2ca3', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('308cb3cb-36ca-4448-b115-51c8cf516956', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('347cdb45-8e0c-4df6-b86a-be7e4eb2c34f', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('35dbbcaf-8871-4962-8460-ac559dd2509f', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 2, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:47', '2025-03-24 10:40:47'),
('3a4fd381-e7d6-443c-b896-beda49a2491b', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 6, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:47', '2025-03-24 10:40:47'),
('3b153af4-715f-478b-a050-998191448191', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('3b82c4c5-aac4-4fb0-8476-895052e1b7fd', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('3b9138d2-f46f-4461-bfb1-08a148249cbb', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('3da8b49e-8db0-4a52-8188-5b762968e439', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('44549066-5a16-4702-93c4-db349e62119f', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('49d82abd-65a3-45b7-987a-16263a5c1a17', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('4b2b1731-796a-4ca2-8757-636bdc04a8a8', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('4cdbd229-49d9-4e3d-bf2b-ff1f43e5d8aa', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('4fa17693-564b-448f-8e7a-a5868c77f466', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 7, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:47', '2025-03-24 10:40:47'),
('550e93f4-afe5-4909-bffd-a6d47ec66e69', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('57117393-9c32-4514-86e6-e33fede589a1', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('586b03dc-3d76-41aa-90d1-4d51f7d3da37', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('5a7b4161-fb03-4637-a92e-2fafcc9a52dd', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('5e200ce4-266e-4ee0-b725-329bf32d4dd5', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('5ecbac37-0b04-11f0-9ea4-0242ac150009', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'a55c60f1-54bc-409f-bcb5-bc12f52bd8c0', '074adda6-080c-11f0-aff0-0242ac150003', 'reserved', 50.00, 'EUR', NULL, NULL, NULL, NULL, NULL, '2025-03-27 12:09:44', '2025-03-27 12:10:30'),
('5ee814d9-4dcf-4ecc-837a-96716d574dda', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('63ac6fd4-d573-45e1-ab00-f0373205f58d', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('674279da-389d-47be-9a6b-b08db019dc98', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('6c10be15-917e-4697-8941-5195ebaf428d', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('6d6ed279-b3e3-4dcc-8e76-fb116702aeaf', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('718a7cae-c112-46c0-b0ac-d603a1ce108b', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('72fa9c99-080d-11f0-9d84-0242ac150006', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', '074adda6-080c-11f0-aff0-0242ac150003', 'purchased', 75.00, 'EUR', '2025-03-23 17:37:10', 'qr_code_data_1', NULL, '{\"row\": \"1\", \"seat\": \"15\", \"section\": \"A\"}', NULL, '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fae9a3-080d-11f0-9d84-0242ac150006', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', '074ae82b-080c-11f0-aff0-0242ac150003', 'purchased', 150.00, 'EUR', '2025-03-23 17:37:10', 'qr_code_data_2', NULL, '{\"row\": \"1\", \"seat\": \"5\", \"section\": \"VIP\"}', NULL, '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72faf180-080d-11f0-9d84-0242ac150006', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', 'f0eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', '074ae93d-080c-11f0-aff0-0242ac150003', 'purchased', 60.00, 'EUR', '2025-03-23 17:37:10', 'qr_code_data_3', NULL, '{\"row\": \"5\", \"seat\": \"10\", \"section\": \"B\"}', NULL, '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72faf4f8-080d-11f0-9d84-0242ac150006', 'e3eebc99-9c0b-4ef8-bb6d-6bb9bd380a13', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', '074aedd5-080c-11f0-aff0-0242ac150003', 'purchased', 120.00, 'EUR', '2025-03-23 17:37:10', 'qr_code_data_4', NULL, '{\"row\": \"20\", \"seat\": \"15\", \"section\": \"C\"}', NULL, '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72faf79d-080d-11f0-9d84-0242ac150006', 'e5eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'g0eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', '074af0a1-080c-11f0-aff0-0242ac150003', 'purchased', 15.00, 'EUR', '2025-03-23 17:37:10', 'qr_code_data_5', NULL, '{\"row\": \"\", \"seat\": \"\", \"section\": \"General\"}', NULL, '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fafa47-080d-11f0-9d84-0242ac150006', 'e6eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 'h0eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', '074af225-080c-11f0-aff0-0242ac150003', 'purchased', 150.00, 'EUR', '2025-03-23 17:37:10', 'qr_code_data_6', NULL, '{\"row\": \"2\", \"seat\": \"7\", \"section\": \"VIP\"}', NULL, '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fafcbd-080d-11f0-9d84-0242ac150006', 'e10ebc99-9c0b-4ef8-bb6d-6bb9bd380a20', 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', '074af7d7-080c-11f0-aff0-0242ac150003', 'purchased', 195.00, 'EUR', '2025-03-23 17:37:10', 'qr_code_data_7', NULL, '{\"row\": \"1\", \"seat\": \"10\", \"section\": \"VIP\"}', NULL, '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('7496f0c4-cde9-4f34-ae6e-7de94067230a', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('74c24026-bc39-4427-a1ab-54e42bd68933', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('831331c2-a65d-4fcf-af2c-48661e4be1d7', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('83d0864a-f6de-4d31-ab6f-cd8c04fe8755', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('886b2d32-b2eb-4656-bd4a-383d862c2ba7', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('8acfa403-cf0c-4041-8aa3-1de9c9c0eac7', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('8b8796df-a4c6-4fe2-80a6-7691bd2c84fa', 'e2eebc99-9c0b-4ef8-bb6d-6bb9bd380a12', NULL, '074ae93d-080c-11f0-aff0-0242ac150003', 'available', 60.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 1, \"section\": \"Standard\"}', NULL, '2025-03-24 10:40:47', '2025-03-24 10:40:47'),
('8ddbbe48-7c42-4fcd-9bb9-d48222377d6d', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('91a55bf3-0bf3-4d70-82d5-7312d4553347', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('933272a1-247b-4001-a02b-570fc5df779e', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('96bdc76a-dafb-4c5f-8cc1-9776d1b54554', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('992b1a3d-75d4-4f3f-a1fe-d90930285642', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('9957d7c8-bad9-4a00-b317-ab7261665b52', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('9da4962e-05b2-44b7-bc45-03db478784e7', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('9e790db9-9339-44ee-940c-92b99315bcd3', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('9fa78dfc-b55a-4bbf-ab7f-80577aa4ecdd', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('a032961f-caef-4f31-826b-4247c9add69b', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('a3c3db51-05df-4e82-8338-fdbef924b751', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('a8b8259c-52b9-4da4-bdb6-2395036ab404', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('aa031709-3c95-49ec-bd03-6496dd4ad232', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('afa487cc-a2eb-42c5-8dcc-8bc86ed13529', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('b265a912-8e99-4b8a-9689-d96b80f953fa', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('b397fe48-321b-4c44-bb4c-99d646aedbc3', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('b5c9f22f-95cf-4aa7-8f23-f63d897ab38f', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('b5f1c17a-5095-40d1-bb07-f4121e8b34bd', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('b65e17ad-9325-4c8c-92c3-6613783514da', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('b6d4b191-0b04-11f0-9ea4-0242ac150009', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'a55c60f1-54bc-409f-bcb5-bc12f52bd8c0', '074adda6-080c-11f0-aff0-0242ac150003', 'reserved', 50.00, 'EUR', NULL, NULL, NULL, NULL, NULL, '2025-03-27 12:12:12', '2025-03-27 12:13:06'),
('b6d4b25d-0b04-11f0-9ea4-0242ac150009', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', NULL, '074adda6-080c-11f0-aff0-0242ac150003', 'available', 50.00, 'EUR', NULL, NULL, NULL, NULL, NULL, '2025-03-27 12:12:12', '2025-03-27 12:12:12'),
('b6d4b27b-0b04-11f0-9ea4-0242ac150009', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', NULL, '074adda6-080c-11f0-aff0-0242ac150003', 'available', 50.00, 'EUR', NULL, NULL, NULL, NULL, NULL, '2025-03-27 12:12:12', '2025-03-27 12:12:12'),
('b6d4b291-0b04-11f0-9ea4-0242ac150009', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', NULL, '074adda6-080c-11f0-aff0-0242ac150003', 'available', 50.00, 'EUR', NULL, NULL, NULL, NULL, NULL, '2025-03-27 12:12:12', '2025-03-27 12:12:12'),
('b6d4b2a3-0b04-11f0-9ea4-0242ac150009', 'e1eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', NULL, '074adda6-080c-11f0-aff0-0242ac150003', 'available', 50.00, 'EUR', NULL, NULL, NULL, NULL, NULL, '2025-03-27 12:12:12', '2025-03-27 12:12:12'),
('b9c53292-19c9-495f-887a-ae2ec3829a54', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('bc135400-fd27-413d-8db3-2d77c0857a73', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('c2421077-dfec-42f9-a7e8-cae388fc8fc7', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('c44db2ee-9b84-4b5b-9815-1b7a3fb6f0f8', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('c67e1bde-2c60-4487-9cf9-3e8dc498a6c6', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('ca7439a9-f77c-40a3-bfab-a5f8801eaca3', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('caa2caed-af88-4abd-b9a6-5251fac4a71a', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('cd7291f2-5907-4ca7-88b7-91fb2b14547d', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('cdb04867-5e4a-4771-8839-9c7660daf18a', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('cdb4fb29-d809-496e-b0a7-b10f8af391dd', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('d1507d01-f860-410f-922c-c07596033e4e', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('d39c1023-396e-47d7-8408-a40373674ef0', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 2, \"seat\": 4}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('d4c58f37-3a45-4130-89e5-eb2e34df75c0', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('d4d1b166-8997-4b57-ac19-70ad0b13fb3b', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 3, \"seat\": 5}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('d53cce89-7359-4465-b9d4-ffd8420ec636', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('d98a95e4-a38b-4268-87d5-432f368a4393', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('dede486f-9b86-46f0-9109-15b4cf6b8abb', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 3}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('e5f3829b-1b61-403d-bd20-5442d5fb881d', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 7, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('eb077f5a-c014-4588-bbac-eacf1f5bc2b4', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 10, \"seat\": 8}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('eee46003-69ea-4998-ac0d-fb010bb6172c', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('efe4a39a-6572-4c2f-b6fb-4a0036e3f324', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 6}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('f01f5f5e-3c45-430a-84b9-78a7b566ce4b', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('f1a94f4f-7185-42d8-977f-1f4697381783', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 1, \"seat\": 7}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('f1b3399e-1c37-41d7-8cc5-327bad6b067e', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('f356533b-c60b-479f-9ac8-de1c2bc8cfb7', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 9, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('f48fa2a3-7509-49e8-8a64-d6d60d9d4a3d', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 5, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('f631bb42-0747-4fe1-8df7-3276b40633ce', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 9}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('f6e2e818-e260-4ee3-b6b4-79dbdba791ec', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 8, \"seat\": 2}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('f9d35456-06f3-4251-a36d-90e006febdff', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('faeabb13-2535-4164-a462-f8676011ecc4', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 6, \"seat\": 1}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01'),
('ff6c71e7-72b9-45b2-ab1b-d363e45437a7', '3f7b10a2-df09-4186-8105-cde827856554', NULL, 'bb6d15da-6a56-48cc-bfb5-ebd3b634f8ad', 'available', 25.00, 'EUR', NULL, NULL, NULL, '{\"row\": 4, \"seat\": 10}', NULL, '2025-03-24 15:25:01', '2025-03-24 15:25:01');

-- --------------------------------------------------------

--
-- Structure de la table `ticketTransactions`
--

CREATE TABLE `ticketTransactions` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `ticketId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `userId` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `type` enum('reservation','purchase','cancellation','refund','transfer','validation') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(255) DEFAULT 'EUR',
  `status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
  `paymentMethod` varchar(255) DEFAULT NULL,
  `paymentReference` varchar(255) DEFAULT NULL,
  `transactionDate` datetime DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `ticketTransactions`
--

INSERT INTO `ticketTransactions` (`id`, `ticketId`, `userId`, `type`, `amount`, `currency`, `status`, `paymentMethod`, `paymentReference`, `transactionDate`, `metadata`, `createdAt`, `updatedAt`) VALUES
('65cc612c-3e0d-4ba0-9e9f-38239411894f', '5ecbac37-0b04-11f0-9ea4-0242ac150009', 'a55c60f1-54bc-409f-bcb5-bc12f52bd8c0', 'reservation', 50.00, 'EUR', 'completed', NULL, NULL, '2025-03-27 12:10:30', NULL, '2025-03-27 12:10:30', '2025-03-27 12:10:30'),
('72fe0fce-080d-11f0-9d84-0242ac150006', '074d8fbe-080c-11f0-aff0-0242ac150003', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'purchase', 75.00, 'EUR', 'completed', 'credit_card', 'tx_123456', '2025-03-23 17:37:10', '{\"paymentDetails\": {\"brand\": \"Visa\", \"last4\": \"1234\"}}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fe4d3f-080d-11f0-9d84-0242ac150006', '074e0f0a-080c-11f0-aff0-0242ac150003', 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'purchase', 150.00, 'EUR', 'completed', 'paypal', 'tx_234567', '2025-03-23 17:37:10', '{\"paymentDetails\": {\"email\": \"user@example.com\"}}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fe55bc-080d-11f0-9d84-0242ac150006', '074e191f-080c-11f0-aff0-0242ac150003', 'f0eebc99-9c0b-4ef8-bb6d-6bb9bd380a16', 'purchase', 60.00, 'EUR', 'completed', 'credit_card', 'tx_345678', '2025-03-23 17:37:10', '{\"paymentDetails\": {\"brand\": \"Mastercard\", \"last4\": \"5678\"}}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fe5b53-080d-11f0-9d84-0242ac150006', '074e1df8-080c-11f0-aff0-0242ac150003', 'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14', 'purchase', 120.00, 'EUR', 'completed', 'credit_card', 'tx_456789', '2025-03-23 17:37:10', '{\"paymentDetails\": {\"brand\": \"Visa\", \"last4\": \"1234\"}}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fe5fb9-080d-11f0-9d84-0242ac150006', '074e2545-080c-11f0-aff0-0242ac150003', 'g0eebc99-9c0b-4ef8-bb6d-6bb9bd380a17', 'purchase', 15.00, 'EUR', 'completed', 'credit_card', 'tx_567890', '2025-03-23 17:37:10', '{\"paymentDetails\": {\"brand\": \"Amex\", \"last4\": \"4321\"}}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fe6225-080d-11f0-9d84-0242ac150006', '074e2a42-080c-11f0-aff0-0242ac150003', 'h0eebc99-9c0b-4ef8-bb6d-6bb9bd380a18', 'purchase', 150.00, 'EUR', 'completed', 'bank_transfer', 'tx_678901', '2025-03-23 17:37:10', '{\"paymentDetails\": {\"bankName\": \"BNP Paribas\"}}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('72fe6625-080d-11f0-9d84-0242ac150006', '074e2da4-080c-11f0-aff0-0242ac150003', 'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15', 'purchase', 195.00, 'EUR', 'completed', 'paypal', 'tx_789012', '2025-03-23 17:37:10', '{\"paymentDetails\": {\"email\": \"user@example.com\"}}', '2025-03-23 17:37:10', '2025-03-23 17:37:10'),
('7d92e315-79a5-4751-90bd-1f026ee428d7', 'b6d4b191-0b04-11f0-9ea4-0242ac150009', 'a55c60f1-54bc-409f-bcb5-bc12f52bd8c0', 'reservation', 50.00, 'EUR', 'completed', NULL, NULL, '2025-03-27 12:13:06', NULL, '2025-03-27 12:13:06', '2025-03-27 12:13:06');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `ticketInventories`
--
ALTER TABLE `ticketInventories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventoryId` (`inventoryId`);

--
-- Index pour la table `ticketTransactions`
--
ALTER TABLE `ticketTransactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticketId` (`ticketId`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`inventoryId`) REFERENCES `ticketInventories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ticketTransactions`
--
ALTER TABLE `ticketTransactions`
  ADD CONSTRAINT `ticketTransactions_ibfk_1` FOREIGN KEY (`ticketId`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
